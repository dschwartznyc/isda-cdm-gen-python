from enum import Enum

all = ['MoneyMarketTypeEnum']
  
class MoneyMarketTypeEnum(Enum):
  CERTIFICATE_OF_DEPOSIT = "CERTIFICATE_OF_DEPOSIT"
  COMMERCIAL_PAPER = "COMMERCIAL_PAPER"
